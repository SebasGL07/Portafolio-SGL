﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            {
                Console.WriteLine("1) ConversorTemps");
                Console.WriteLine("2) CompatibilidadSangre");

                int opcion = Convert.ToInt32(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        ConversorTemps();
                        break;

                    case 2:
                        CompatibilidadSangre();
                        break;
                }
            }
        }        //PROBLEMA 1:
            //1. Falso
            //2. Verdadero
            //3. Falso
            //4. Verdadero

            //PROBLEMA 2:
            static void ConversorTemps()
            {
                Console.Write("ingrese la temperatura: ");
                double numero = Convert.ToDouble(Console.ReadLine());
                Console.Write("Ingrese el numero de la temperatura a convertir: ");
                Console.Write("1) de Celsius a Fahrenheit");
                Console.Write("2) de Fahrenheit a Celsius");
                Console.Write("3) de Celsius a Kelvin");
                int Escala = Convert.ToInt32(Console.ReadLine());
                switch (Escala)
                {
                    case 1:
                        double Escala1 = (numero * 1.8) + 32;
                        Console.Write("Su temperatura de Celsius a Fahrenheit es: " + Escala1);
                        break;
                    case 2:
                        double Escala2 = (numero - 32.0) * (5.0 / 9.0);
                        Console.Write("Su temperatura de Faherenheit a Celcius es: " + Escala2);
                        break;

                    case 3:
                        double Escala3 = (numero + 273.15);
                        Console.Write("Su temperatura de Celsius a Kelvin es: " + Escala3);
                        break;
                }
            }

            // PROBLEMA 3: 
            static void CompatibilidadSangre()
            {
                Console.Write("ingrese su tipo de sangre: ");
                string sangre = Console.ReadLine();
                sangre = sangre.ToUpper();
                switch (sangre)
                {
                    case "A+":
                        Console.Write("Es compatible con: O-, O+, A- & A+");
                        break;

                    case "A-":
                        Console.Write("Es compatible con: O- & A-");
                        break;

                    case "AB+":
                        Console.Write("Es compatible con: O-, O+, AB+, AB-, B+, B-, A- & A+");
                        break;

                    case "AB-":
                        Console.Write("Es compatible con: O-, AB-, B- & A-");
                        break;

                    case "B-":
                        Console.Write("Es compatible con: O- & B- ");
                        break;

                    case "B+":
                        Console.Write("Es compatible con: O-, O+, B- & B+");
                        break;

                    case "O-":
                        Console.Write("Es compatible con: O- solamente ");
                        break;

                    case "O+":
                        Console.Write("Es compatible con: O- & O+ ");
                        break;

                    default:
                        Console.Write("Tipo de sangre no válido.");
                        break;
                }
            }


        }
    }