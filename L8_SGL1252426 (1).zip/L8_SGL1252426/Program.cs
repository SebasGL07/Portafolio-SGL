using System;

class Program {
    static void Main() {

        // EJERCICIO 1
        Console.WriteLine("=== EJERCICIO 1 ===");
        double suma = 0;

        Console.Write("Ingrese el número 1: ");
        int primero = int.Parse(Console.ReadLine());
        int mayor = primero;
        int menor = primero;
        suma += primero;

        for (int i = 2; i <= 20; i++) {
            Console.Write("Ingrese el número " + i + ": ");
            int num = int.Parse(Console.ReadLine());
            suma += num;
            if (num > mayor) mayor = num;
            if (num < menor) menor = num;
        }

        double promedio = suma / 20;
        Console.WriteLine("\nNúmero mayor: " + mayor);
        Console.WriteLine("Número menor: " + menor);
        Console.WriteLine("Promedio: " + promedio);

        // EJERCICIO 2
        Console.WriteLine("\n=== EJERCICIO 2 ===");

        for (int i = 1; i <= 100; i++) {
            if (i % 2 == 0 && i % 7 == 0) {
                Console.WriteLine(i + " - ParSiete");
            } else if (i % 2 == 0) {
                Console.WriteLine(i + " - Par");
            } else if (i % 7 == 0) {
                Console.WriteLine(i + " - Siete");
            } else {
                Console.WriteLine(i);
            }
        }

        // EJERCICIO 3
        Console.WriteLine("\n=== EJERCICIO 3 ===");
        int clientesConDescuento = 0;
        double totalVentas = 0;

        for (int i = 1; i <= 10; i++) {
            Console.Write("Ingrese el monto de compra del cliente " + i + ": ");
            double monto = double.Parse(Console.ReadLine());

            double descuento = 0;
            if (monto > 700) {
                descuento = monto * 0.12;
                clientesConDescuento++;
            } else if (monto > 300) {
                descuento = monto * 0.05;
                clientesConDescuento++;
            }

            double totalPagado = monto - descuento;
            totalVentas += totalPagado;

            Console.WriteLine("  Cliente " + i + " - Monto original: Q" + monto +
                              " | Descuento: Q" + descuento +
                              " | Total pagado: Q" + totalPagado);
        }

        Console.WriteLine("\nClientes que recibieron descuento: " + clientesConDescuento);
        Console.WriteLine("Total de ventas del día: Q" + totalVentas);

        // EJERCICIO 4
        Console.WriteLine("\n=== EJERCICIO 4 ===");
        Console.Write("Ingrese un número entero: ");
        int n = int.Parse(Console.ReadLine());

        Console.WriteLine("Elige una opción:");
        Console.WriteLine("1. Mostrar números desde " + n + " hasta 1");
        Console.WriteLine("2. Mostrar múltiplos de 3 hasta " + n);
        Console.WriteLine("3. Mostrar múltiplos de 5 hasta " + n);
        Console.Write("Opción: ");
        int opcion = int.Parse(Console.ReadLine());

        if (opcion == 1) {
            Console.WriteLine("Números de " + n + " hasta 1:");
            for (int i = n; i >= 1; i--) {
                Console.Write(i + " ");
            }
            Console.WriteLine();
        } else if (opcion == 2) {
            Console.WriteLine("Múltiplos de 3 hasta " + n + ":");
            for (int i = 3; i <= n; i += 3) {
                Console.Write(i + " ");
            }
            Console.WriteLine();
        } else if (opcion == 3) {
            Console.WriteLine("Múltiplos de 5 hasta " + n + ":");
            for (int i = 5; i <= n; i += 5) {
                Console.Write(i + " ");
            }
            Console.WriteLine();
        } else {
            Console.WriteLine("Opción no válida.");
        }

        // EJERCICIO 5
        Console.WriteLine("\n=== EJERCICIO 5 ===");
        Console.Write("Ingrese el número de filas: ");
        int filas = int.Parse(Console.ReadLine());

        Console.WriteLine("Triángulo:");
        for (int i = 1; i <= filas; i++) {
            for (int j = 1; j <= i; j++) {
                Console.Write("*");
            }
            Console.WriteLine();
        }

        Console.WriteLine("\nPresiona Enter para salir...");
        Console.ReadLine();

    }
}
